package Cars;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
/**
 * Created by nitsche on 2016-01-27.
 */
 class Inlamning {

    public static void main(String[] args) {
        //getRef();

        ACar s = new Saab95();
        ACar v= new Volvo240();

        dynamicTestCheck(s);
        dynamicTestCheck(v);
    }

    public static void dynamicTestCheck(ACar rawr){
        System.out.println(rawr.getColor());
        System.out.println(rawr.getEnginePower());
        System.out.println(rawr.modelName);
        System.out.println(rawr.getCurrentSpeed());
    }
    public static void getRef(){
        Method[] methods = Scania.class.getMethods();
        Field[] fields = Scania.class.getDeclaredFields();
        String className = Scania.class.getName();


        System.out.println(className);
        for(Field field : fields){
            System.out.println("Field = " + field.getName());
        }
        for(Method method : methods){
            System.out.println("method = " + method.getName());
        }

        className = Volvo240.class.getName();
        System.out.println(className);

        methods = Volvo240.class.getMethods();
        fields = Volvo240.class.getFields();

        for(Field field : fields){
            System.out.println("Field = " + field.getName());
        }
        for(Method method : methods){
            System.out.println("method = " + method.getName());
        }

        className = Saab95.class.getName();
        System.out.println(className);

        methods = Saab95.class.getMethods();
        fields = Saab95.class.getFields();

        for(Field field : fields){
            System.out.println("Field = " + field.getName());
        }
        for(Method method : methods){
            System.out.println("method = " + method.getName());
        }


    }
}


