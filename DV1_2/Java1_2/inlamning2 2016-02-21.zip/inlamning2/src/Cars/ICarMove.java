/**
 * Created by nitsche on 2016-01-27.
 */
package Cars;
public interface ICarMove {
    void move();
    void turnLeft();
    void turnRight();
}


