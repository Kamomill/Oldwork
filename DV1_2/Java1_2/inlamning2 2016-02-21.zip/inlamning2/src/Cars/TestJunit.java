/**
 * Created by nitsche on 2016-02-08.
 */
package Cars;
//Commented away because i junit was messing around on my home-pc
/*
import junit.framework.TestCase;
import org.junit.Test;

import java.awt.*;

import static org.junit.Assert.*;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class TestJunit extends TestCase {

    Saab95 s1 = new Saab95();
    Volvo240 v1 = new Volvo240();
    Scania c1 = new Scania();

    @Test
    public void testAdd() {

        List of asserts
        assertEquals();
        assertArrayEquals();
        assertFalse();
        assertNotEquals();
        assertNull();
        assertSame();
        assertTrue();



//-- Test colour set() and change() for Saab --
         assertEquals(s1.getColor(), Color.RED);

         s1.setColor(Color.BLUE);
         assertEquals(s1.getColor(), Color.BLUE);
//-- End test colour set() and change() for Saab --

//-- Test colour set() and change() for Volvo --
        assertEquals(v1.getColor(), Color.BLACK);

        v1.setColor(Color.GREEN);
        assertEquals(v1.getColor(), Color.GREEN);
//-- End test colour set() and change() for Volvo --


//-- Test currentSpeed(), gas(), brake(), incrementSpeed(), decrementSpeed() and turbo() for Saab --


        assertTrue(s1.getCurrentSpeed() == 0);

        s1.brake(1);
        assertTrue(s1.getCurrentSpeed() == 0);

        s1.brake(-1);
        assertTrue(s1.getCurrentSpeed() == 0);

        s1.gas(0);
        assertTrue(s1.getCurrentSpeed() == 0);

        s1.gas(0.5);
        assertTrue(s1.getCurrentSpeed() == 0.625);

        s1.currentSpeed=0;

        s1.gas(1);
        assertTrue(s1.getCurrentSpeed() == s1.speedFactor() * 1);

        s1.gas(10);
        assertTrue(s1.getCurrentSpeed() == s1.speedFactor() * 2); //gas(1)*2

        s1.currentSpeed=0;

        assertTrue(s1.getCurrentSpeed() == 0);

        s1.setTurboOn();
        s1.gas(1);
        assertTrue(s1.getCurrentSpeed() == s1.speedFactor() * 1);
        s1.setTurboOff();

        s1.currentSpeed = s1.getEnginePower();

        s1.gas(1);
        assertTrue(s1.getCurrentSpeed() == s1.getEnginePower());
//--End test currentSpeed(), gas(), brake(), incrementSpeed(), decrementSpeed() and turbo() for Saab --
        assertEquals(s1.getNrDoors(), 2);
//-- Test currentSpeed(), gas(), brake(), incrementSpeed() and decrementSpeed() for Volvo --



        assertTrue(v1.getCurrentSpeed() == 0);

        v1.brake(1);
        assertTrue(v1.getCurrentSpeed() == 0);

        v1.brake(-1);
        assertTrue(v1.getCurrentSpeed() == 0);

        v1.gas(0);
        assertTrue(v1.getCurrentSpeed() == 0);

        v1.gas(0.5);
        assertTrue(v1.getCurrentSpeed() == 0.625);

        v1.currentSpeed=0;
        v1.gas(1);
        assertTrue(v1.getCurrentSpeed() == v1.speedFactor() * 1);

        v1.gas(10);
        assertTrue(v1.getCurrentSpeed() == v1.speedFactor() * 2); //gas(1)*2

        v1.currentSpeed=0;
        assertTrue(v1.speedFactor()== (v1.enginePower * 0.01) * v1.trimFactor);
        assertTrue(s1.speedFactor()== ((s1.enginePower * 0.01) * 1)); //s1.turbo=false
        v1.currentSpeed=0;

        v1.currentSpeed=0;
        assertTrue(v1.getCurrentSpeed() == 0);

        v1.currentSpeed = v1.getEnginePower();

        v1.gas(1);
        assertTrue(v1.getCurrentSpeed() == v1.getEnginePower());
        v1.startEngine();

//--End test currentSpeed(), gas(), brake(), incrementSpeed() and decrementSpeed() for Volvo --



    }
    @Test
    public void testMove(){

        assertSame(s1.direction, ACar.Direction.UP);

        s1.turnRight();
        assertNotSame(s1.direction,ACar.Direction.UP);
        assertSame(s1.direction, ACar.Direction.RIGHT);

        s1.direction = ACar.Direction.DOWN;
        assertSame(s1.direction, ACar.Direction.DOWN);
        s1.turnLeft();
        assertSame(s1.direction, ACar.Direction.RIGHT);

        assertEquals(s1.position.getX(),0.0);
        assertEquals(s1.position.getY(),0.0);

        s1.move();
        assertNotSame(s1.position.getX(),0);
        assertNotSame(s1.position.getY(),0);

    }

    @Test
    public void testScania(){

        assertTrue(c1.getBedDegree() == 0);
        assertTrue(c1.getBedIsDown());

        c1.lowerBed(); //Checks so it dont go >0
        assertTrue(c1.getBedDegree() == 0);

        c1.liftBed();
        assertTrue(c1.getBedDegree() == 1);

        c1.liftBed(9);
        assertTrue(c1.getBedDegree() == 10);

        c1.liftBed(-10);
        assertTrue(c1.getBedDegree() == 0);

        c1.liftBed(true);
        assertTrue(c1.getBedDegree() == 70);
        c1.honk();
        c1.decrementSpeed(23);
        c1.incrementSpeed(23);

        //Inlamning.main();
    }
}*/