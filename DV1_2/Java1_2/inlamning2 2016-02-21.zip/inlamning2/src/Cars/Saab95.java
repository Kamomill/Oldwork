package Cars;
import java.awt.*;

public class Saab95 extends ACar{

    private boolean turboOn;
    
    public Saab95(){
        nrDoors = 2;
        color = Color.red;
        enginePower = 125;
	    turboOn = false;
        modelName = "Saab95";
        stopEngine();
        this.position.setLocation(0,0);
    }

    public void setTurboOn(){
	    turboOn = true;
    }

    public void setTurboOff(){
	    turboOn = false;
    }


    /**
     * @return returns the speed factor of a Saab95
     */
    @Override
    public double speedFactor(){
        double turbo = 1;
        if(turboOn) turbo = 1.3;
        return (enginePower * 0.01) * turbo;
    }


    //gas() and brake() is placed in ACar since all cars gas and brakes the same way...

//Overrides has been changed so they override the interface
// These methods is placed in ACar since all cars move and turn the same way...
}
