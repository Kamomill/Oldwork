package Cars;
import java.awt.*;

public class Volvo240 extends ACar {

    final static double trimFactor = 1.25;

    public Volvo240() {
        nrDoors = 4;
        color = Color.black;
        enginePower = 100;
        modelName = "Volvo240";
        stopEngine();
    }

    /**
     * @return returns the speed factor of a Volvo240
     */
    @Override
    public double speedFactor() {
        return (enginePower * 0.01) * trimFactor;
    }

    //gas() and brake() is placed in ACar since all cars gas and brakes the same way...

    //Overrides has been changed so they override the interface
    //These methods is placed in ACar since all cars move and turn the same way...
}

