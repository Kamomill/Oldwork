package Cars;
import java.awt.*;

abstract class ACar implements ICarMove {

    enum Direction {RIGHT, LEFT, UP, DOWN}

    protected Direction direction = Direction.UP;
    protected Point.Double position = new Point.Double(); //default point for the car, x=0,y=0

    protected int nrDoors; // Number of doors on the car
    protected double enginePower; // Engine power of the car
    protected double currentSpeed; // The current speed of the car
    protected Color color; // Color of the car
    protected String modelName; // The car model name

    /**
     * @return the number of doors of a car has
     */
    public int getNrDoors(){
        return nrDoors;
    }

    /**
     * @return the engine power of a car
     */
    public double getEnginePower(){
        return enginePower;
    }

    /**
     * @return the speed factor of a car
     */
    public double speedFactor(){ return enginePower * 0.01; }

    /**
     * @return the current speed of a car
     */
    public double getCurrentSpeed(){
        return currentSpeed;
    }

    /**
     * Starts engine
     */
    public void startEngine() {currentSpeed = 0.1; }

    /**
     * Stops engine
     */
    public void stopEngine(){ currentSpeed = 0; }

    /**
     * @return the Color of a car
     */
    public Color getColor(){
        return color;
    }

    public void setColor(Color clr){
        color = clr;
    }

    /**
     * @return the Position of a car as a Point (x,y)
     */
    public Point.Double getPosition(){return position;}



    /**
     * Gates the incrementSpeed
     * @param amount is the amount the car accelerates
     */
    public void gas(double amount) {
        if (amount < 0) {
            incrementSpeed(0);
        } else if (amount > 1) {//Changed from 0 to 1, it was not in the interval [0,1] just in the points 1 and 0
            incrementSpeed(1);
        } else {
            incrementSpeed(amount);
        }
    }

    /**
     * Gates the decrementSpeed
     * @param amount is the amount the car brakes
     */
    public void brake(double amount) {
        if (amount < 0) {
            decrementSpeed(0); //Changed to decrementSpeed from incrementSpeed
        } else if (amount > 1) {//Changed from 0 to 1, it was not in the interval [0,1] just in the points 1 and 0
            decrementSpeed(1); //Changed to decrementSpeed from incrementSpeed
        } else {
            decrementSpeed(amount); //Changed to decrementSpeed from incrementSpeed
        }
    }

    /**
     *  checks the current position and moves X,Y accordingly
     */
    public void move() {
        switch (this.direction) {
            case LEFT:
                this.position = new Point.Double(this.position.getX() - this.getCurrentSpeed(), this.position.getY());
                break;
            case UP:
                this.position = new Point.Double(this.position.getX(), this.position.getY() + this.getCurrentSpeed());
                break;
            case RIGHT:
                this.position = new Point.Double(this.position.getX() + this.getCurrentSpeed(), this.position.getY());
                break;
            case DOWN:
                this.position = new Point.Double(this.position.getX(), this.position.getY() - this.getCurrentSpeed());
                break;
        }
    }
    /**
     * Turns left
     */
    public void turnLeft() {
        switch (this.direction) {
            case LEFT:
                this.direction = Direction.DOWN;
                break;
            case UP:
                this.direction = Direction.LEFT;
                break;
            case RIGHT:
                this.direction = Direction.UP;
                break;
            case DOWN:
                this.direction = Direction.RIGHT;
                break;
        }
    }
    /**
     * Turns right
     */
    public void turnRight() {
        switch (this.direction) {
            case LEFT:
                this.direction = Direction.UP;
                break;
            case UP:
                this.direction = Direction.RIGHT;
                break;
            case RIGHT:
                this.direction = Direction.DOWN;
                break;
            case DOWN:
                this.direction = Direction.LEFT;
                break;
        }
    }

    /**
     *Increments the speed of the car
     * @param amount - speed modifier
     */
    public void incrementSpeed(double amount){
        currentSpeed = Math.min (getCurrentSpeed() + speedFactor() * amount , enginePower); //Math.min was missing
    }
    /**
     *Decrements the speed of the car
     * @param amount - speed modifier
     */
    public void decrementSpeed(double amount){
        currentSpeed = Math.max (getCurrentSpeed() - speedFactor() * amount , 0); // Math.max was missing
    }




}
