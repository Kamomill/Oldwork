package Cars;
import java.awt.*;
/**
 * Created by nitsche on 2016-02-08.
 */
public class Scania extends ACar {

    private boolean bedIsDown;
    private	int bedDegree;

    Scania(){
        nrDoors = 2;
        color = Color.red;
        enginePower = 200;
        modelName = "Scania";
        bedDegree = 0;
        bedIsDown = true;
}


    public int getBedDegree(){return bedDegree;}
    public boolean getBedIsDown(){return bedIsDown;}


    public void isDegree() {
        if (bedDegree == 0 && currentSpeed == 0){ //[Q1]NOTE LOGIC ERROR?  dö, de´ e´ fixat´!
            bedIsDown = true;}
        else if (bedDegree > 0 ) {
            bedIsDown = false;}
    }

    public void lowerBed(){
        bedDegree = Math.max(bedDegree - 1,0);
        isDegree();
    }

    public void liftBed(){bedDegree = Math.min(bedDegree + 1,70); isDegree();}

    public void liftBed(int degrees){
        if (degrees >= 0) {
            for (int i = 0; i < degrees; i++) {  //Secured to not exceed limit of 70 degrees
                liftBed();

            }
        } else {
            for (int i = 0; i > degrees; i--){   //Secured to not have a negative degree
                lowerBed();

            }
        }
    }

    public void liftBed(boolean position){
        if (position){
            bedDegree = 70;
        }
        else{
            bedDegree = 0;
        }
        }

    public void honk(){System.out.println("HONK  HONK!");}


    public void decrementSpeed(double amount){}
    public void incrementSpeed(double amount){}
}
