package samples.products.pig;

import java.util.Random;

/**
 *  A Dice class for the Pig game
 */
public class Dice {   // Dice class must be in file Dice.java

    // All attributes private (other objects can't access)
    private static final Random rand = new Random();  //Shared by all instances
    private final int nFaces;

    public Dice(int nFaces) {
        this.nFaces = nFaces;
    }

    public Dice() {
        this(6);       // Default value
    }

    // Public, for other objects to call
    public int roll() {
        return rand.nextInt(nFaces) + 1;
    }
}
