package samples.products.pig;

/**
 * Player fot the Pig game
 */
public class Player {   // Player class in file Player.java

    // All attributes private (other objects can't access)
    private final int ordinal;
    private final String name;
    private int points = 0;


    public Player(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    // All methods public, for other objects to call
    public void add(int total) {
        points = points + total;
    }

    public boolean isWinner(int total ) {
        return points + total >= Pig.WIN_POINTS;
    }

    // Name private so need getter
    public String getName() {
        return name;
    }

    // Points private so need getter
    public int getPoints() {
        return points;
    }

    public Player getNext(Player[] players) {
        return players[(ordinal + 1) % players.length];
    }

}
