package samples.products.pig;

import java.util.Scanner;
import static java.lang.System.*;
/**
 * Full OO version of Pig game (i.e. classes in separate files, using public and private)
 *
 */
public class Pig {   // This class must be in file Pig.java

    public static void main(String[] args) {
        new Pig().program();
    }

    public static final int WIN_POINTS = 20;        // static = shared by all instances (we only have one)
    private static final String ROLL = "r";         // Private not accessible in other class
    private static final String NEXT = "n";
    private static final String QUIT = "q";

    private static final Scanner scan = new Scanner(in);

    private void program() {

        final Dice dice = new Dice(6);
        final Player[] players = {new Player("Olle", 0), new Player("Pelle", 1), new Player("Fia", 2)};
        int total = 0;
        boolean aborted = false;
        boolean done = false;
        int result = 0;
        Player actual = players[0];

        // Setup
        gameStartMessage(players);
        while (!done) {

            String command = getCommand(actual);

            switch (command) {
                case ROLL:
                    // --- Input ------------
                    result = dice.roll();     // Call public method

                    // ----- Process ----------
                    if (result > 1) {
                        total = total + result;
                        if (actual.isWinner(total)) {   // Call public method
                            actual.add(total);           // Call public method
                            done = true;
                        }
                    } else {
                        actual = actual.getNext(players);   // Call public method
                        total = 0;
                    }

                    // ------- Output ---------
                    if (result > 1) {
                        roundSuccessMsg(result, total);
                    } else {
                        roundFailMsg();
                    }
                    break;
                case NEXT:
                    // --- Process -------
                    actual.add(total);
                    actual = actual.getNext(players);
                    total = 0;
                    // ---- Output -------
                    statusMsg(players);
                    break;
                case QUIT:
                    aborted = true;
                    break;
                default:
                    out.println("?");
            }

            if (aborted) {
                break;
            }

        }

        gameOverMsg(aborted, actual, players);

    }  // End program

    // Private methods only accessible in this class --------------------------------
    private void roundSuccessMsg(int result, int total) {
        out.println("Got " + result + " total is " + total);
    }

    private void roundFailMsg() {
        out.println("Got 1 lost it all!");
    }

    private void gameStartMessage(Player[] players) {
        out.println("Welcome to PIG!");
        out.println("Commands are: roll = r, next = n, quit = q");
        statusMsg(players);
    }

    private String getCommand(Player actual) {
        // Must use get-methods, can't access name
        out.print("Player is " + actual.getName() + " > ");
        return scan.nextLine();
    }

    // Must use get-methods, can't access name and points
    private void statusMsg(Player[] players) {
        out.println(players[0].getName() + " = " + players[0].getPoints() +
                " " + players[1].getName() + " = " + players[1].getPoints() +
                " " + players[2].getName() + " = " + players[2].getPoints());
    }

    void gameOverMsg(boolean aborted, Player actual, Player[] players) {
        if (aborted) {
            out.println("Aborted");
        } else {
            statusMsg(players);
            out.println("Game over! Winner is " + actual.getName());
        }
    }

}


