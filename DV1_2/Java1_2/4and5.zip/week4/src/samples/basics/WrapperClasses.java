package samples.basics;

import static java.lang.System.*;
import static java.lang.Math.*;

/**
 * Using wrapper classes for primitives;
 */
public class WrapperClasses {

    public static void main(String[] args) {
        new WrapperClasses().program();
    }

    private void program() {

        Integer i = 4;   // Conversion from int to Integer ...
        int j = i;        // ... and back

        Double d = i + 5.0;    // Conversions (unbox, then to double)

        // Will convert to int elements to Integer
        Integer[] is = {1, 2, 3, 4, 5, 6, 7, 8, 9};

        int[] k = {1, 2, 3};
        //Integer[] l = k;      // No can't convert arrays

        // Now we can use method for (wrapped) primitive types
        rotateLeftOneO(is);

        testInteger();
        testDouble();

    }


    // Check out some static methods in Integer, Double, etc
    private void testInteger() {
        out.println(Integer.max(45, 67));
        out.println(Integer.min(45, 67));
        out.println(Integer.toString(123));
        out.println(Integer.valueOf("456") + 10);
        out.println(Integer.MAX_VALUE);
        out.println(Integer.MIN_VALUE);
    }

    private void testDouble() {
        // Double should handle about 15 decimals
        Double d1 = 10.0;
        Double d2 = 10.00000000000001;  // 14 dec. OK
        Double d3 = 10.00000000000002;
        Double d4 = 10.0000000000000002;  // 16 dec. NO!

        out.println( abs( d1 - d2 ) != 0);
        out.println( abs( d2 - d3 ) != 0);
        out.println( abs( d1 - d4 ) == 0);

        out.println(Double.compare(d1, d2) != 0);
        out.println(Double.compare(d2, d3) != 0);
        out.println(Double.compare(d1, d4) == 0);  // Java can't handle
    }


    // This will work for any array! Using Object as type
    private void rotateLeftOneO(Object[] objects) {
        Object tmp = objects[0];
        for (int i = 0; i < objects.length - 1; i++) {
            objects[i] = objects[i + 1];
        }
        objects[objects.length - 1] = tmp;
    }


}
