package samples.basics;

import static java.lang.System.*;
import static java.lang.Math.*;

/**
 * A Integer Matrix class using 2D arrays
 *
 * For usage see TestOtherClasses
 */
public class Matrix {
    private final int nRows;  // Convenience
    private final int nCols;
    private final int[][] elems;  // Matrix elements

    // Constructor Assume square matrix
    public Matrix(int[] array) {
        this.nRows = (int) sqrt(array.length);
        this.nCols = nRows;
        elems = new int[nRows][nCols];
        toMatrix(array);
    }

    // Constructor Non-square matrix
    public Matrix(int[] array, int rows, int cols) {
        this.nRows = rows;
        this.nCols = cols;
        elems = new int[nRows][nCols];
        toMatrix(array);
    }

    // Help method (private)
    private void toMatrix(int[] array) {
        for (int i = 0; i < array.length; i++) {
            elems[i / nCols][i % nCols] = array[i];
        }
    }

    public int sumCol(int index) {
        int sum = 0;
        for (int row = 0; row < nRows; row++) {
            sum += elems[row][index];
        }
        return sum;
    }

    public int get(int row, int col) {
        return elems[row][col];
    }

    public void set(int row, int col, int value) {
        elems[row][col] = value;
    }

    public int get(int index) {
        return elems[index / nCols][index % nCols];
    }

    public void set(int index, int value) {
        elems[index / nCols][index % nCols] = value;
    }

    public boolean isInside(int row, int col) {
        return row >= 0 && col >= 0 && row < nRows && col < nCols;
    }

    // To get nice out.println()
    public String toString() {
        String s = "[";
        for (int row = 0; row < nRows; row++) {
            for (int col = 0; col < nCols; col++) {
                s += elems[row][col];
                if (col != nCols - 1) {
                    s += ", ";
                }
            }
            if (row != nRows - 1) {
                s += lineSeparator();  // From System (platform independent new line)
            }
        }
        return s + "]";
    }
}
