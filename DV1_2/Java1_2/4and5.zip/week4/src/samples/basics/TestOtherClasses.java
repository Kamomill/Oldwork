package samples.basics;

import static java.lang.System.*;

/**
 * A class to test other sample classes Order, Matrix and enum WeekDay
 */
public class TestOtherClasses {

    public static void main(String[] args) {
        new TestOtherClasses().program();
    }

    private void program() {
        //testOrder();
        //testWeekDay();
        testMatrix();
    }


    private void testOrder() {
        Order o1 = new Order();
        Order o2 = new Order();

        out.println(o1.getOrderNumber());
        out.println(o2.getOrderNumber());
        out.println(Order.getLastOrderNumber());

    }

    private void testWeekDay() {
        WeekDay d1 = WeekDay.FRI;
        WeekDay d2 = WeekDay.THU;
        //WeekDay d3 = "SUN";    // No SUN is a string, wrong type
        WeekDay d4 = WeekDay.FRI;

        out.println(d1 != d2);
        out.println(d1 == d4);


        WeekDay[] days = WeekDay.values();
        for (WeekDay w : days) {
            out.println(w);
        }
        WeekDay d5 = WeekDay.valueOf("SUN");  // String must be exactly as enum  "SUN" <-> SUN

    }

    private void testMatrix() {
        Matrix m = new Matrix(new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9});
        out.println(m);
        out.println(m.get(4));
        out.println(m.get(0, 0));
        out.println(m.sumCol(2) == 18);

        m.set(8, 0);
        m.set(1, 1, 34);
        out.println(m);
        out.println(m.isInside(2, 2));
        out.println(!m.isInside(-1, 2));
        out.println(!m.isInside(2, 3));


    }
}
