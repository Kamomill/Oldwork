package samples.basics;

/**
 * Enumeration class for days (better than using Strings, type safe)
 *
 * For usage see TestOtherClasses
 */
public enum WeekDay {
    MON, TUE, WED, THU, FRI, SAT, SUN
}
