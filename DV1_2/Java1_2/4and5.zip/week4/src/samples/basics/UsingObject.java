package samples.basics;

import java.util.Arrays;

import static java.lang.System.*;

/**
 * Using the Object class and arrays of Objects
 */
public class UsingObject {

    public static void main(String[] args) {
        new UsingObject().program();
    }

    private void program() {
        Object o = new Object();    // Object variable may reference any non-primitive type!!
        o = new Order();            // Order referenced as Object
        o = "Hello";                // String referenced as Object

        out.println(o);

        useObjectArray();

    }

    public void useObjectArray() {
        String[] names = {"olle", "pelle", "fia"};
        Order[] orders = {new Order(), new Order(), new Order(), new Order()};

        // Using overloaded version
        rotateOneLeft(names);
        out.println(Arrays.toString(names));
        rotateOneLeft(orders);
        out.println(Arrays.toString(orders));

        // Using Object version (works for any array)
        rotateLeftOneO(names);
        rotateLeftOneO(orders);
        out.println(Arrays.toString(names));
        out.println(Arrays.toString(orders));

        // Must use wrapper type for primitive values
        Integer[] ii = new Integer[]{1, 2, 3, 4, 5};
        rotateLeftOneO(ii);
        out.println(Arrays.toString(ii));

    }


    // Overloaded ok but need method for each type
    private void rotateOneLeft(String[] names) {
        String tmp = names[0];
        for (int i = 0; i < names.length - 1; i++) {
            names[i] = names[i + 1];
        }
        names[names.length - 1] = tmp;
    }

    // Overloaded
    private void rotateOneLeft(Order[] orders) {
        Order tmp = orders[0];
        for (int i = 0; i < orders.length - 1; i++) {
            orders[i] = orders[i + 1];
        }
        orders[orders.length - 1] = tmp;
    }

    // This will work for any array! Using Object as type
    // NOTE: We can't do much with the instances, only methods from Object accessible
    private void rotateLeftOneO(Object[] objects) {
        Object tmp = objects[0];
        for (int i = 0; i < objects.length - 1; i++) {
            objects[i] = objects[i + 1];
        }
        objects[objects.length - 1] = tmp;
    }
}
