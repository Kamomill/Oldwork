package samples.basics;

/**
 *  Class/instance variables and methods
 *
 *  For usage see TestOtherClasses
 */
public class Order {

    // Class variable shared by all
    private static int orderNumberCounter;     // Not final (not possible here)! Bad! Dangerous!
    // Instance variable number for each instance
    private final int orderNumber;

    public Order(){
        this.orderNumber = orderNumberCounter;    // Assign this order number
        orderNumberCounter++;                    // Increment for next order
    }

    // Instance method accessing instance variable, OK!
    public int getOrderNumber(){
        return orderNumber;
    }

    // Class method accessing class variable, OK!
    public static int getLastOrderNumber(){
        return orderNumberCounter;
    }


    // ----- Variations ----------------

    // Instance method accessing class variable, OK (but name conflict)
    /*public int getLastOrderNumber(){
        return orderNumberCounter;
    }*/

    // Class method accessing instance variable, NO!
    /*public static int getLastOrderNumber2(){
        return orderNumber;            // Senseless, which object is it????
    }*/

    public String toString(){
        return "" + orderNumber;
    }
}
