package exercises.basics;


import java.util.Arrays;

import static java.lang.System.out;


/**
 * Testing the Matrix class
 */
public class TestMatrix {


    public static void main(String[] args) {
        new TestMatrix().program();
    }

    void program() {
        // This is just testing. Output should be true or a plotted matrix
        Matrix m = new Matrix(new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9});
        out.println(m);
        out.println(m.get(4) == 5);
        out.println(m.get(0, 0) == 1);
        m.set(8, 0);
        m.set(1, 1, 0);
        out.println(m.get(8) == 0);
        out.println(m.get(1, 1) == 0);
        out.println(m.isInside(2, 2));
        out.println(!m.isInside(-1, 2));
        out.println(!m.isInside(2, 3));
        out.println(m.sumCol(2));


        // Test your added methods using the rows below ---------------
        out.println();
        Matrix m2 = new Matrix(new int[]{11, 22, 33, 44, 55, 66}, 2, 3);
        out.println(m2);
        out.println(m2.sumNeighbors(1, 2));
        out.println(m2.sumNeighbors(1, 2) == 110); // Do this before swapping
        out.println(Arrays.toString(m2.toArray()));  // [ 11, 22, 33, 44, 55, 66 ]
        m2.randomSwap();
        out.println(m2);  // [ ?, ?, ?, ?, ?, ? ]

    }


}

