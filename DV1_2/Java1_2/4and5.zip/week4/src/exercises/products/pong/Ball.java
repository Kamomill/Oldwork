package exercises.products.pong;

import java.awt.*;
import java.util.Random;

import static java.lang.Math.*;

/**
 * Class for a ball
 */
class Ball {



    public Ball(double x, double y, int maxX, int maxY) {

    }



}
