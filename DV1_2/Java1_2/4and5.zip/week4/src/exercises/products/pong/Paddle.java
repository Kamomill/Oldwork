package exercises.products.pong;

/**
 * Class for a Paddle
 */
class Paddle {



}



