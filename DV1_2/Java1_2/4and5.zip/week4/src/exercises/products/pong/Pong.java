package exercises.products.pong;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

/**
 * Pong-like game (only one player)
 *
 * Main class and application entry
 *
 * NOTE: All graphics here
 *
 *   *** You may change all classes to fit your needs ***
 */
public class Pong extends JPanel implements ActionListener {

    public static void main(String[] args) {
        new Pong().program();
    }

    private final int width = 600;
    private final int height = 400;
    private final int interval = 10;
    private final int delay = 1000;
    private final int paddleSpeed = 5;
    private final int paddleHeight = 60;
    private final int paddleWidth = 5;
    //final Paddle paddle = new Paddle(width - 50, (height - paddleHeight) / 2,
      //      paddleWidth, paddleHeight, paddleSpeed, height);
    private Ball ball;
    private int points;
    private int highScore;

    private void program() {
        initGraphics();
        initEvents();
    }

    private void update() {

    }


    public void actionPerformed(ActionEvent e) {
        update();
        repaint();
    }

    public void paint(Graphics g) {

    }


    private void drawBall(Graphics2D g2, Ball ball) {

    }

    private void drawPaddle(Graphics2D g2, Paddle p) {

    }

    private void initGraphics() {
        setPreferredSize(new Dimension(width, height));
        JFrame window = new JFrame();
        window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        window.add(this);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);
        window.addKeyListener(kl);  // Extra row: Set listener on Window
    }

    private void initEvents() {
        Timer timer = new Timer(interval, this);
        timer.setInitialDelay(delay);
        timer.start();
    }

     private final KeyListener kl = new KeyAdapter() {

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_UP) {
               // paddle.up();
            } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
               // paddle.down();
            }
            // System.out.println(paddle.y);
        }
    };
}
