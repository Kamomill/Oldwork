package exercises.products.simulation;

/**
 * A single actor in the simulation
 */
public class Agent {

    private final Type type;
    private boolean satisfied = true;   // This is the important point!

    public Agent(Type type ) {
        this.type = type;
    }

    // Copy constructor
    public Agent(Agent a) {
        this(a.getType());
    }

    public boolean isSatisfied() {
        return satisfied;
    }

    public boolean setSatisfied(boolean b) {
        return satisfied = b;
    }

    public Type getType() {
        return type;
    }

    public String toString() {
        return "{" + type + "," + satisfied + '}';
    }
}

