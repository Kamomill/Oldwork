package exercises.products.simulation;

/**
 * Types for Agents
 */
public enum Type {
    NONE,
    RED,
    BLUE
}

