package exercises.products.simulation;

import static java.lang.System.*;

/**
 * Test class for Neighbourhood. Only method tested is isSatisfied()
 */
public class TestNeighbourhood {

    public static void main(String[] args) {
        new TestNeighbourhood().test();
    }

    private void test() {
        // 0.5 says if 50% of neighbours same as me then satisfied (NONE-type not counted)
        Neighbourhood n = new Neighbourhood(3, 3, 0.5);
        /*
               R R N
               N B N
               N N B
         */
        n.setData(new Agent[]{new Agent(Type.RED), new Agent(Type.RED), new Agent(Type.NONE),
                new Agent(Type.NONE), new Agent(Type.BLUE), new Agent(Type.NONE),
                new Agent(Type.NONE), new Agent(Type.NONE), new Agent(Type.BLUE),
        });
        out.println(n);

        // All should print true if ok!
        out.println(n.isSatisfied(0, 0)); // The red
        out.println(n.isSatisfied(0, 1)); // Other red
        out.println(!n.isSatisfied(1, 1)); // Blue
        out.println(n.isSatisfied(2, 2)); // Other blue
        out.println(n.isSatisfied(0, 2)); // Not used in practise, type is NONE

        // Other methods hard to test (uses random)
    }


}
