package exercises.products.calc;

import java.util.Scanner;
import static java.lang.System.*;
/**
 *  Commandline to run the Calculator
 */
public class CommandLineCalc {

    public static void main(String[] args) {
        new CommandLineCalc().program();
    }

    private void program() {
        Scanner scan = new Scanner(in);

        while (true) {
            out.print("> ");
            String input = scan.nextLine();
            try {
                double result = Calculator.eval(input);
                out.println(result);
            }catch( Exception e){
                out.println(e.getMessage());
            }
        }
    }


}
