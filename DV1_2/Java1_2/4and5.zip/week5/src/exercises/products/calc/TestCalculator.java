package exercises.products.calc;

import static java.lang.System.*;
import static exercises.products.calc.Calculator.*;

/**
 * This is a test program for the Calculator
 * It should output true for everything
 */
public class TestCalculator {


    public static void main(String[] args) {
        new TestCalculator().test();
    }

    private void test() {

        // Tokenization
        t("1 +10", 11);
        t("1+ 10", 11);
        t("1+10", 11);
        t(" 1+10 ", 11);

        // A value
        t("123", 123);

        // Basic operations
        t("1 + 10", 11);
        t("1 + 0", 1);
        t("1 - 10", -9);  // Input may not be negative but output may
        t("10 - 1", 9);
        t("60 * 10", 600);
        t("60 * 0", 0);
        t("3 / 2", 1.5);  // See exception for div by zero
        t("1 / 2", 0.5);
        t("2 ^ 4 ", 16);
        t("2 ^ 0 ", 1);

        // Associativity
        t("10 - 5 - 2", 3);  // (10-5)-2
        t("20 / 2 / 2", 5);  // (20/2)/2
        t("4 ^ 2 ^ 2", 256);  // 4^(2^2)

        // Precedence
        t("3 * 10 + 2", 32);
        t("3 + 10 * 2", 23);
        t("30 / 3 + 2", 12);
        t("1 + 30 / 3", 11);
        t("3 * 2 ^ 2", 12);
        t("3 ^ 2 * 2", 18);

        // Parentheses
        t("10 - (5 - 2)", 7);
        t("20 / (10 / 2)", 4);
        t("(3 ^ 2) ^ 2", 81);
        t("3 * (10 + 2)", 36);
        t("30 / (3 + 2)", 6);
        t("(3 + 2) ^ 2", 25);
        t(" 2 ^ (1 + 1)", 4);

        // Exceptions
        try {
            t("1 / 0 ", 0);   // 0 just a dummy
        } catch (IllegalArgumentException e) {
            out.println(e.getMessage().equals(DIV_BY_ZERO));
        }
        try {
            t("", 0);
        } catch (IllegalArgumentException e) {
            out.println(e.getMessage().equals(NO_INPUT));
        }
        try {
            t("1 + 2 + ", 0);
        } catch (IllegalArgumentException e) {
            out.println(e.getMessage().equals(MISSING_OPERAND));
        }
        try {
            t("12 3", 0);
        } catch (IllegalArgumentException e) {
            out.println(e.getMessage().equals(MISSING_OPERATOR));
        }
        try {
            t("1 + 2)", 0);
        } catch (IllegalArgumentException e) {
            out.println(e.getMessage().equals(MISSING_OPERATOR));
        }
        try {
            t("(1 + 2", 0);
        } catch (IllegalArgumentException e) {
            out.println(e.getMessage().equals(MISSING_OPERATOR));
        }

    }

    // t for test, a very short name, lazy, avoid typing ...
    private void t(String expr, double value) {
        if (eval(expr) == value) {
            out.println(eval(expr) == value);
        } else {
            out.println("Fail " + expr);
        }
    }
}
