package exercises.unused;

import static java.lang.Math.*;
import static java.lang.System.*;

/**
 * Using a Quad to generate key for localization in plane
 * (plane partitioned into squares, partitioned into squares ,etc)
 * <p>
 * <p>
 * -------------- width, height
 * |  01  |  11  |
 * ------00 ------
 * |  00  |  10  |
 * 0,0 -----------
 */
public class Quad {

    public static void main(String[] args) {
        new Quad().program();
    }

    private void program() {
        out.println(getQuadKey(50, 50).equals("000000"));
        out.println(getQuadKey(150, 50).equals("000010"));
        out.println(getQuadKey(50, 150).equals("000001"));
        out.println(getQuadKey(150, 150).equals("000011"));
        out.println(getQuadKey(67, 43).equals("000000"));
        out.println(getQuadKey(100, 100).equals("0000"));
        out.println(getQuadKey(300, 300).equals("0011"));
        out.println(getQuadKey(200, 200).equals("00"));
        out.println(getQuadKey(0, 0).equals(""));
        out.println(getQuadKey(400, 400).equals(""));


        out.println(getQuadKey(150, 100).equals("0000"));
        out.println(getQuadKey(50, 100).equals("0000"));
        out.println(getQuadKey(100, 50).equals("0000"));
        out.println(getQuadKey(100, 150).equals("0000"));
    }


    public String getQuadKey(double a, double b) {
        return getQuadKey(a, b, 400, 400);
    }

    public String getQuadKey(double a, double b, double width, double height) {

        StringBuilder key;
        if (!inside(a, b, 0, width, 0, height)) {
            return "";
        } else {
            key = new StringBuilder();
            key.append("00");
        }

        double xl = 0;           // x left
        double xr = width;       // x right
        double yb = 0;           // y bottom
        double yt = height;      // y top

        while (abs(xr - xl) > (width / 4)) {
            double midX = mid(xr, xl);
            double midY = mid(yt, yb);

            if (inside(a, b, xl, midX, yb, midY)) {   // Left bottom
                xr = midX;
                yt = midY;
                key.append("00");
            } else if (inside(a, b, xl, midX, midY, yt)) {  // Left top
                xr = midX;
                yb = midY;
                key.append("01");
            } else if (inside(a, b, midX, xr, yb, midY)) { // Right bottom
                xl = midX;
                yt = midY;
                key.append("10");
            } else if (inside(a, b, midX, xr, midY, yt)) {  // Right top
                xl = midX;
                yb = midY;
                key.append("11");
            } else {  // If on border "parent" key returned
                break;
            }
        }
        return key.toString();
    }

    private boolean inside(double x, double y, double xLeft, double xRight, double yBottom, double yTop) {
        return xLeft < x && x < xRight && yBottom < y && y < yTop;
    }

    private double mid(double a, double b) {
        return (a + b) / 2;
    }

}
