package samples.basics;

import java.util.*;

import static java.lang.System.*;

/**
 * Using a Stack (a data structure)
 */

public class UseAStack {


    public static void main(String[] args) {
        new UseAStack().program();
    }

    public void program() {
        Deque<Integer> s = new ArrayDeque<>();

        out.println(s.isEmpty());

        s.push(1);
        out.println(s.peek());
        s.push(2);
        out.println(s.peek());
        s.push(3);
        out.println(s.peek());
        out.println(s.size() == 3);

        int i = s.pop();
        out.println(i == 3);          // Reverse order
        out.println(s.size() == 2);

        s.pop();
        s.pop();
        out.println(s.isEmpty());

        s.push(99);
        s.push(100);
        s.clear();
        out.println(s.isEmpty());

    }

}
