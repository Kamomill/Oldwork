package samples.basics;

import java.util.Arrays;
import java.util.function.Function;

import static java.lang.System.out;

/**
 * Higher order functions in Java
 * Composition also possible but not shown
 */
public class HigherOrderFunctions {
    public static void main(String[] args) {
        new HigherOrderFunctions().program();
    }

    private void program() {
        // Use class method
        plot(0.0, 1.0, Math::sin);

        // Use instance method
        int[] is = map(new double[]{1, -2, 3, -6, 0}, new Utils()::sign);
        out.println(Arrays.toString(is));

        testCompose();

    }

    public int[] map(double[] in, Function<Double, Integer> f) {
        int out[] = new int[in.length];
        for (int i = 0; i < in.length; i++) {
            out[i] = f.apply(in[i]);   // Must call apply to run function
        }
        return out;
    }

    public void plot(double d1, double d2, Function<Double, Double> f) {
        for (double d = d1; d < d2; d += 0.2) {
            out.println(f.apply(d));   // Must call apply to run function
        }
    }


    public void testCompose() {
        // Using "lambdas" anonymous methods (defined in-line)
        Function<Integer, Integer> times2 = e -> 2 * e;   // Right side is a lambda
        Function<Integer, Integer> squared = e -> e * e;

        out.println(times2.compose(squared).apply(4)); // 32
        // Swap order of execution
        out.println(times2.andThen(squared).apply(4)); // 64
    }


    // ---- Utility class ----------------

    class Utils {
        public int sign(double d) {
            if (d < 0) {
                return -1;
            } else if (d > 0) {
                return 1;
            } else {
                return 0;
            }
        }
    }


}
