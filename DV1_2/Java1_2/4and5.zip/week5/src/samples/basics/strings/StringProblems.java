package samples.basics.strings;

import static java.lang.System.*;

import java.lang.StringBuilder;

/**
 * Some typical String problems
 */
public class StringProblems {

    public static void main(String[] args) {
        new StringProblems().program();
    }

    private void program() {
        out.println(toRobber("Jag talar rövarspråket").
                equals("JoJagog totalolaror rorövovarorsospoproråkoketot"));

        /*
        for( String s : generatePredecessors(16)){
            out.println(s);
        }*/

        //out.println(rle("aaaaabbbbccccddeffffff").equals("5a4b4c2d1e6f"));

    }

    // Translate to Robber language
    public String toRobber(String text) {
        StringBuilder sb = new StringBuilder();
        for (char ch : text.toCharArray()) {
            if (isVowel(ch) || Character.isSpaceChar(ch)) {
                sb.append(ch);
            } else {
                sb.append(ch).append("o").append(ch);
            }
        }

        return sb.toString();
    }

    // Helper
    public boolean isVowel(char c) {
        return "aeiouyåäö".indexOf(c) > -1 || "AEIOUYÅÄÖ".indexOf(c) > -1;
    }

    // Run length encoding (possibly could use one loop)
    public String rle(String source) {
        StringBuilder dest = new StringBuilder();
        for (int i = 0; i < source.length(); i++) {
            int runLength = 1;
            while (i + 1 < source.length() && source.charAt(i) == source.charAt(i + 1)) {
                runLength++;
                i++;
            }
            dest.append(runLength);
            dest.append(source.charAt(i));
        }
        return dest.toString();
    }

    // Generate a list of *all* predecessors like ME:mum.dad.mum.mum.dad...
    private String[] generatePredecessors(int max) {
        String[] strs = new String[max + 1];
        strs[0] = "ME";
        for (int i = 0; i < max / 2; i++) {
            strs[2 * i + 1] = strs[i] + ".dad";
            strs[2 * i + 2] = strs[i] + ".mum";
        }
        return strs;
    }


}
