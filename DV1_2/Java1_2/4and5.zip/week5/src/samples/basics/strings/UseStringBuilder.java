package samples.basics.strings;

import static java.lang.System.*;

/**
 * Using a StringBuilder
 */
public class UseStringBuilder {


    public static void main(String[] args) {
        new UseStringBuilder().program();
    }

    private void program() {
        StringBuilder sb = new StringBuilder();

        sb.append("Hello").append(" ").append("World"); // Chained calls
        out.println(sb.toString());


        sb = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            if (sb.length() % 50 == 0) {
                sb.append(lineSeparator());
            } else {
                sb.append("a");
            }
        }

        out.println(sb.toString());

    }

}
