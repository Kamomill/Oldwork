package samples.basics.strings;

import static java.lang.System.*;

/**
        Using the "this trick", i.e. returning this to make chained calls on SAME
        object possible
        This is how Java StringBuilder works internally
 */
public class StringBuilderThis {


    public static void main(String[] args) {
        new StringBuilderThis().program();
    }

    private void program() {
        MyStringBuilder msb = new MyStringBuilder();
        // Chained calls with SAME object
        out.println( msb.append("hello").append(" ").append("goodbye").toString());
    }


    public class MyStringBuilder {
        private char[] chars = new char[8];
        private int actualLen = 0;


        public MyStringBuilder append(String s) {
            if (s.length() + actualLen > chars.length) {
                resize(s.length() + actualLen);
            }
            // Fastest way to copy an array (don't need to learn)
            System.arraycopy(s.toCharArray(), 0, chars, actualLen, s.length());
            actualLen += s.length();
            return this;         // <------------------------ THIS trick
        }


        private void resize(int capacity) {
            char[] chs;
            if (capacity < 2 * chars.length) {
                chs = new char[2 * chars.length];
            } else {
                chs = new char[2 * (chars.length + capacity)];
            }
            System.arraycopy(chars, 0, chs, 0, actualLen);
            chars = chs;
        }

        public String toString(){
            return String.valueOf(chars).trim();
        }
    }

}
